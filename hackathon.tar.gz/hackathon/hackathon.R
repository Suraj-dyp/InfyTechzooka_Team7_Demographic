library("plotrix")
data <- read.table("part-00000") 
con <- "yes"


#----------------------------------agewise
infants <- subset(data,V2=="Infants")
kids <- subset(data,V2=="Kids")
youth <- subset(data,V2=="Youth") 		
middle_aged <-subset(data,V2=="MiddeleAge") 		
elders <- subset(data,V2=="Elders")

agedata <- c(nrow(infants),nrow(kids),nrow(youth),nrow(middle_aged),nrow(elders))
names(agedata)<- c("infants","kids","youth","middle_aged","elders")

#print(agedata)

#----------------------residentWise
rural <- subset(data,V3 == "Rural")
urban <-subset(data,V3 == "Urban")
metro<-subset(data,V3 == "Metro")

residentdata <- c(nrow(rural),nrow(urban),nrow(metro))
names(residentdata) <- c("rural","urban","metro")

ind <- subset(rural,V5=="TraditionalWear")
bw <- subset(rural,V5=="BusinessWear")
cw <- subset(rural,V5=="CasualWear")

hat <- c(nrow(ind),nrow(bw),nrow(cw))
names(hat) <- c("traditional","business wear","casual wear")
#pie(hat,main="Rural Area")


ind2 <- subset(rural,V5=="TraditionalWear")
bw2 <- subset(rural,V5=="BusinessWear")
cw2 <- subset(rural,V5=="CasualWear")

hat1 <- c(nrow(ind2),nrow(bw2),nrow(cw2))
names(hat1) <- c("traditional","business wear","casual wear")
#pie(hat1,main="Urban Area")

ind1 <- subset(rural,V5=="TraditionalWear")
bw1 <- subset(rural,V5=="BusinessWear")
cw1 <- subset(rural,V5=="CasualWear")

hat2 <- c(nrow(ind1),nrow(bw1),nrow(cw1))
names(hat2) <- c("traditional","business wear","casual wear")
#pie(hat2,main="Metro Area")

#-----------------priceAffordable
lowcost <- subset(data,(V4>0) & (V4 < 600))
average <-subset(data,(V4>=600) & (V4 < 5000))
costly <-subset(data,(V4>=5000) & (V4 < 10000))
lavish <-subset(data,(V4>=10000) )

pricedata <- c(nrow(lowcost),nrow(average),nrow(costly),nrow(lavish))
names(pricedata) <- c("lowcost","average","costly","lavish")

#pie(pricedata)
#print(pricedata)

#----------------clothing_line
indian <- subset(data,V5=="TraditionalWear")
businesswear <- subset(data,V5=="BusinessWear")
casualwear <- subset(data,V5=="CasualWear")

clothdata <- c(nrow(indian),nrow(casualwear),nrow(businesswear))
names(clothdata) <- c("indian","casualwear","businesswear")

x <- max(indian$V4)
y <- sum(indian$V4)/1000

x1 <- max(businesswear$V4)
y1 <- sum(businesswear$V4)/nrow(businesswear)


x2 <- max(casualwear$V4)
y2 <- sum(casualwear$V4)/nrow(casualwear)

xt <- c(x,y)
yt <- c(x1,y1)
zt <- c(x2,y2)


 
#pie(clothdata)
#print(clothdata)



#-----------------------------------------------
while(con == "yes"){

cat("1. categories\n")
cat("2. Analysis\n")
cat("3. Price range of all products")


cat("\n\nEnter your choice....>>")
ch <- readline()

	if(ch == 1){

		cat("1. Agewise\n")
		cat("2. Residentwise\n")
		cat("3. Costwise\n")
		cat("4. Clothing Line\n")

		cat("\nEnter your choice: \n")
		cch <- readline()
		if(cch == 1){
			pie(agedata,main="Age-wise ")
			print(agedata)
		}

		if(cch == 2){
			pie(residentdata,main="Area-wise")
		}

		if(cch == 3){
			pie(pricedata,main="Cost-wise")
		}

		if(cch == 4){
			pie(clothdata,main="Clothing-Line")
		}

	}

	if(ch == 2){

		cat("1. urban\n")
		cat("2. rural\n")
		cat("3. metro\n")

		cat("\nEnter your choice: \n")
		cch <- readline()		

		if(cch == 1){
			pie(hat1,main="Urban Area")
		}
		if(cch == 2){
			pie(hat,main="Rural Area")
		}

		if(cch == 3){
			pie(hat2,main="Metro Area")
		}
	}
	
	if(ch == 3){
		par(mfrow=c(3,1))
		pie(xt,main="indian wear range")
		pie(yt,main="business wear range")
		pie(zt,main="casual wear range")
		
	}
	
	
cat("Do u want to continue(yes/no)...")
con <- readline()
}

#-----------------------------------------------
